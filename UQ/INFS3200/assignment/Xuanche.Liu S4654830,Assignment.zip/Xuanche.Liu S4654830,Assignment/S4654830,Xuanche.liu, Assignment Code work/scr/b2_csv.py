#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from book import book as bk

def b2_loader():
    try:       
        lines = pd.read_csv("../dataset/Book2.csv",header=None)
        if lines is None:
            print("invalid line.")
            return
        books = []

        for i in range(len(lines[0])):
            book = bk()
            pubdate = None
            if lines[3][i] in range(0,20):
                year = str(lines[3][i]+2000)
                month = str(lines[4][i])
                day = str(lines[5][i])
                pubdate= day[:-2]+'/'+ month[:-2]+'/'+year[:-2]
            else:
                year = str(lines[3][i]+1900)
                month = str(lines[4][i])
                day = str(lines[5][i])
                pubdate= day[:-2]+'/'+ month[:-2]+'/'+year[:-2]
            book.set_id(lines[0][i])
            book.set_title(lines[1][i])
            book.set_author(lines[2][i])
            book.set_pubdate(pubdate)
            book.set_publisher(lines[7][i])
            book.set_ISBN13(lines[8][i])
            book.set_pages(lines[11][i])
            books.append(book)
        return books

    except:
        print("Error occurred. Check if file exists.")
        


# In[ ]:




