#!/usr/bin/env python
# coding: utf-8

# In[3]:


class book:
    def __init__(self, id=None, title=None, author=None,pubdate=None, publisher=None, ISBN13=None, pages=None):

        self._id = id
        self._title = title
        self._author = author
        self._pubdate = pubdate
        self._publisher = publisher
        self._ISBN13 = ISBN13
        self._pages = pages

    def get_id(self):
        return self._id

    def get_title(self):
        return self._title

    def get_author(self):
        return self._author

    def get_pubdate(self):
        return self._pubdate
    
    def get_publisher(self):
        return self._publisher
    
    def get_ISBN13(self):
        return self._ISBN13
    
    def get_pages(self):
        return self._pages


    
    def set_id(self, value):
        self._id = value

    def set_title(self, value):
        self._title = value

    def set_author(self, value):
        self._author = value

    def set_pubdate(self, value):
        self._pubdate = value

    def set_publisher(self, value):
        self._publisher = value
        
    def set_ISBN13(self, value):
        self._ISBN13 = value
        
    def set_pages(self, value):
        self._pages = value


# In[ ]:




