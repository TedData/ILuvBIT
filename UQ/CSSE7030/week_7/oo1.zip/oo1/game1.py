#!/usr/bin/env python3
####################################################
# A Model View Controller (MVC) application for a simple adventure game
#
# The Model class requires the following interface:
# Constructor : Model()
# Methods:
#  get_character() - get the character object
#  get_items() - get the items
#  character_take_item() - find an item that is sufficiently close to the 
#         character and if one found the character takes that item, 
#         otherwise do nothing
#
# The Character class requires the following interface:
# Constructor :  Character(x, y, name)
# Methods:
#  move(deltax, deltay) - offset the (x,y) position by (deltax, deltay)
#  get_position() - get the x,y coord of the character
#  get_inventory() - get the players inventory
#  take(item) - add item to inventory
#  drop(index) - drop the item at given index (in inventory) - do nothing if 
#          index out of range
#  hold(index) - hold the item at given index (in inventory) - do nothing if 
#          index out of range
#  get_holding() - get the item being held (None if nothing held)
#
# The Item class requires the following interface:
# Constructor : Item(x, y, name)
# Methods:
#  set_position(x, y) - put the item at location (x,y)
#  is_taken() - return True iff player has the item
#  set_taken(t) - set the taken flag to the boolean t
#  get_position() - get the x,y coord of the character
#
####################################################
#
# WARNING: This code uses some more advanced features which we will see
# later in the course. We will work on GUIs shortly. 
# There is also a use of list comprehension taht we will see in the last 
# section of the course.
#
#####################################################


# imports for the GUI
import tkinter as tk 
from tkinter import messagebox

# import the model from model2.py
from model1 import *

# the dimensions of the canvas
WIDTH = 550 #750
HEIGHT = 550 #750

# the distance (in pixels) travelled by the player when an arrow key is pressed
DELTA = 10


# Typically to make your own widgets you inherit from a frame (a container)
# and add widgets to that frame
class Status(tk.Frame):
    """The status bar widget for the character"""
    def __init__(self, master, parent, char):
        super().__init__(master)
        self.parent = parent
        self.char = char
        # A label to list the inventory (as text)
        tk.Label(self, text= "Inventory: ").pack(side=tk.LEFT)
        self.inventory = tk.Label(self, text= "")
        self.inventory.pack(side=tk.LEFT,fill=tk.X)

    def update_inventory(self):
        """Update the inventory label with the current inventory

        update_inventory() -> None
        """
        # the text includes the index so the user can choose an item
        # the item being held is prefixed by a '*'
        text = ' '.join("{0}:{1}{2}".\
                        format(i,
                               ("*" if self.char.get_holding() == item else ""),
                               str(item)) \
                        for i,item in enumerate(self.char.get_inventory()))
        # update the inventory label with the new inventory text
        self.inventory.configure(text=text)


class GameApp(object):
    """The application"""
    def __init__(self, master):   
        master.title("Game1")
        self._master = master
        # Create the model
        self.model = Model()
        # extract the character object from the model
        self.char = self.model.get_character()
        # Create the canvas where game objects will be drawn
        self._canvas = tk.Canvas(master, bg='grey100', 
                                 width=WIDTH, height=HEIGHT)
        self._canvas.pack(expand=1, fill=tk.BOTH)
        # Bind a key press event to teh key_press method - i.e. call
        # key_press each time a key is pressed
        self._canvas.bind_all("<Key>", self.key_press)
        # create the character status bar
        self.status_bar = Status(master, self, self.char)
        self.status_bar.pack(expand=1, fill=tk.X, padx=20, pady = 10)
        # the following 2 flags are used for keyboard interaction
        self.doing_drop = False
        self.doing_hold = False
        # for efficiency the GIFs are preloaded into a dictionary
        self.images = { 
            "player":tk.PhotoImage(file = 'data/player.gif'),
            "sword":tk.PhotoImage(file = 'data/sword.gif'),
            "dagger":tk.PhotoImage(file = 'data/dagger.gif'),
            "potion":tk.PhotoImage(file = 'data/potion.gif'),
        }
        char_image_name = self.char.get_name()
        # the character image doesn't change so preload for efficiency
        self.char_image = self.images[char_image_name]
        # display all game objects and update the character status info
        self.show()


    def show(self):
        """Show all the game objects and update the character status bar

        show() -> None
        """
        # The simplest approach to displaying the current state of the game
        # on the canvas is to delete everything and redraw everything
        self._canvas.delete(tk.ALL)

        items = self.model.get_items()
        # draw all the items (not in character inventory)
        for item in items:
            if item.is_taken():
                # don't draw the item if the character has the item
                continue
            x, y = item.get_position()
            name = item.get_name()
            image = self.images[name]
            self._canvas.create_image(x, y, image = image)

        # draw the character
        x, y = self.char.get_position()
        self._canvas.create_image(x, y, image = self.char_image)
        item_held = self.char.get_holding()
        # if the character is holding an item draw that
        if item_held is not None:
            name = item_held.get_name()
            image = self.images[name]
            self._canvas.create_image(x+10, y-10, image = image)
        self.status_bar.update_inventory()


    def key_press(self, e):
        """Modify game based on key pressed

        key_press(KeyObject) -> None

        Arrow keys: move character in that direction by a given amount
        't' : take the item near character
        'd' followed by number key (index) : drop that item
        'h' followed by number key (index) : hold that item
        """
        key = e.keysym
        
        if self.doing_drop:
            # 'd' was previous key pressed
            self.doing_drop = False
            if key in "0123456789":
                self.char.drop(int(key))
                self.show()
                return
        if self.doing_hold:
            # 'h' was previous key pressed
            self.doing_hold = False
            if key in "0123456789":
                self.char.hold(int(key))
                self.show()
                return

        self.doing_drop = False
        self.doing_hold = False

        if key == 'Up':
            self.char.move(0,-DELTA)
        elif key == 'Down':
            self.char.move(0,DELTA)
        elif key == 'Left':
            self.char.move(-DELTA,0)
        elif key == 'Right':
            self.char.move(DELTA,0)
        elif key == 't':
            self.model.character_take_item()
        elif key == 'd':
            self.doing_drop = True
        elif key == 'h':
            self.doing_hold = True
        
        self.show()

def main():
    root = tk.Tk()
    app = GameApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()
